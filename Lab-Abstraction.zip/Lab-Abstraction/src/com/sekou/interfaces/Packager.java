package com.sekou.interfaces;

import com.sekou.model.Package;

public interface Packager {
	
	public Package assemblePackage();

}
