package com.sekou;

public class Node {

}
