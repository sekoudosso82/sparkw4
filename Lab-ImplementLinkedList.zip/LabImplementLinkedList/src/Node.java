
public class Node {
	Node next;
    Integer data;
    
//    public Node(Integer data) {  
//        this.data = data;  
//        this.next = null;  
//    }  

}
