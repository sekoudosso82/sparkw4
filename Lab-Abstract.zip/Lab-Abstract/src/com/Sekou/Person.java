package com.Sekou;

public abstract class Person {
	
	protected String name;

    public abstract String getName();

    public abstract void setName(String name);

}
