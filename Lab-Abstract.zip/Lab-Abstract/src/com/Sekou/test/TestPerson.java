package com.Sekou.test;

import com.Sekou.Person;

public class TestPerson {
	
	// constructor 
	
	public static void main(String[] args) {
        Person adam = new Person(); // cannot instantiate the type Person 
    }

}
